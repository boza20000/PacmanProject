#pragma once
//Solution to course project # <5>
//Introduction to programming course
//Faculty of Mathematics and Informatics od Sofia University
//Winter semester 2024/2025
//
//@author <Boris Dimitrov Tsvetkov>
//idNumber <6MI0600504
//@compiler Microsoft Visual Studio compiler
//header file with helper variables

const char wallSymbol = '#';
const char foodSymbol = '@';
const char pointSymbol = '.';
const char emptySymbol = ' ';
char** grid = nullptr;
int widthGrid = 0, heightGrid = 0;

/*void setConsoleCursorPosition(int x, int y);
void updateGridCell(int x, int y, char symbol);
bool isFoodEaten(char ch);
bool isPointEaten(char ch);
void hideConsoleCursor();
void clearConsole();
void resizeConsole(int height, int width);
void centerConsole();
void skipLineInFile();
void addBoundaryWalls();
void loadMapFromFile();
void renderGrid();
void initializeGridMemory(int rows, int cols);
void freeGridMemory();
void prepareConsoleForGame();
void initializeGridDimensions();
void displayPlayerScore();*/