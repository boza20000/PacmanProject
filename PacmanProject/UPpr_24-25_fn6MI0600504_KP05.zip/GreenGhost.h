#pragma once
//Solution to course project # <5>
//Introduction to programming course
//Faculty of Mathematics and Informatics od Sofia University
//Winter semester 2024/2025
//
//@author <Boris Dimitrov Tsvetkov>
//idNumber <6MI0600504
//@compiler Microsoft Visual Studio compiler
//header file with helper variables for the ghosts
const char clydeSymbol = 'C';
const size_t clydeNumber = 3;
const char* greenColor = "\033[32m";
const size_t scoreToActivtGreen = 60;
int greenLastX = -1;
int greenLastY = -1;