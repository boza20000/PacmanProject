#pragma once
//Solution to course project # <5>
//Introduction to programming course
//Faculty of Mathematics and Informatics od Sofia University
//Winter semester 2024/2025
//
//@author <Boris Dimitrov Tsvetkov>
//idNumber <6MI0600504
//@compiler Microsoft Visual Studio compiler
//header file with helper variables for the ghosts
const char pinkySymbol = 'Y';
const size_t pinkyNumber = 1;
const char* pinkColor = "\033[35m";
const size_t scoreToActivtPink = 20;
int pinkLastX = -1;
int pinkLastY = -1;