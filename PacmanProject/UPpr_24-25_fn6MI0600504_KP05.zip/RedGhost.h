#pragma once
//Solution to course project # <5>
//Introduction to programming course
//Faculty of Mathematics and Informatics od Sofia University
//Winter semester 2024/2025
//
//@author <Boris Dimitrov Tsvetkov>
//idNumber <6MI0600504
//@compiler Microsoft Visual Studio compiler
//header file with helper variables for the ghosts
const char blinkySymbol = 'B';
const size_t blinkyNumber = 0;
const char* redColor = "\033[31m";
const size_t scoreToActivtRed = 0;
int redLastX = -1;
int redLastY = -1;