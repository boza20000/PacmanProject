#pragma once
//Solution to course project # <5>
//Introduction to programming course
//Faculty of Mathematics and Informatics od Sofia University
//Winter semester 2024/2025
//
//@author <Boris Dimitrov Tsvetkov>
//idNumber <6MI0600504
//@compiler Microsoft Visual Studio compiler
//header file with helper variables for the ghosts

const char inkySymbol = 'I';
const size_t inkyNumber = 2;

const char* cyanColor = "\033[36m";
const size_t scoreToActivtBlue = 40;
int blueLastX = -1;
int blueLastY = -1;